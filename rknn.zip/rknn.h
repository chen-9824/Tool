#ifndef RKNN_H
#define RKNN_H

#include <QObject>

#include <QPoint>
#include <QSize>
#include <QImage>

#include "yolov5.h"

class Rknn : public QObject
{
    Q_OBJECT

public:
    struct rknn_process_para{
        uint obj_class_num;
        uint box_prob_size;
        float nms_thresh;
        float box_thresh;
    };


public:
    explicit Rknn(QString model_path, const QString &model_labels_path, QSize screen_size, QSize rknn_img_size, const uint obj_class_num, const uint box_prob_size, QObject *parent = nullptr);

    int init();
    void deinit();
    void start();
    void stop();
    void start_inference(const QImage &image);
    void start_human_inference(const QImage &image);
    void stop_inference();
    void set_recongnize_rect(QPoint top_left, QSize size);

    QPoint convertCoordinates(const QPoint &p, const QSize& fromRes, const QSize& toRes);

signals:
    void infernce_res(int res);

private:
    bool is_infernce = false;
    QPoint _rect_top_left;
    QPoint _rect_right_bottom;
    //QSize _rect_size;
    QString _model_path;
    QString _model_labels_path;
    QSize _img_size;
    QSize _screen_size;

    int _obj_class_num = 0;
    int _prob_box_size = 0;

    QImage _img;

    int storage_human_img_num = 0;
    int storage_common_guangai_img_num = 0;
    int storage_empty_guangai_img_num = 0;
    QString storage_img_path = "/home/ido/chenFan/Acid/inference_img";

    bool is_run = true;

    rknn_app_context_t rknn_app_ctx;

};

#endif // RKNN_H
