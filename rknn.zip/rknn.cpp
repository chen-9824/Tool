#include "rknn.h"

#include "yolov5.h"
#include "image_utils.h"
#include "file_utils.h"
#include "image_drawing.h"

#include <QThread>
#include <QDebug>
#include <QElapsedTimer>

#include <iostream>
#include <fstream>
#include <string>

Rknn::Rknn(QString model_path, const QString &model_labels_path, QSize screen_size, QSize rknn_img_size, const uint obj_class_num, const uint box_prob_size, QObject *parent)
    : QObject(parent), _model_path(model_path), _model_labels_path(model_labels_path), _obj_class_num(obj_class_num), _prob_box_size(box_prob_size)
{

    qDebug() << "model_path" << _model_path;
    qDebug() << "model_labels_path" << _model_labels_path;

    //_img_size = QSize(1280, 720);
    //_screen_size = QSize(1280, 800);

    _img_size = rknn_img_size;
    _screen_size = screen_size;

}

int Rknn::init()
{
    _img = QImage();
    is_run = true;

    //QPoint top_left(0, 0);
    //QSize size(0, 0);
    //set_recongnize_rect(top_left, size);

    int ret = 0;

    memset(&rknn_app_ctx, 0, sizeof(rknn_app_context_t));

    init_post_process(_obj_class_num, _model_labels_path.toStdString().c_str());

    ret = init_yolov5_model(_model_path.toStdString().c_str(), &rknn_app_ctx);
    if (ret != 0)
    {
        qDebug("init_yolov5_model fail! ret=%d model_path=%s\n", ret, _model_path.toStdString().c_str());
        return ret;
    }

    qDebug("init_yolov5_model success! ret=%d model_path=%s\n", ret, _model_path.toStdString().c_str());
    return ret;
}

void Rknn::deinit()
{
    deinit_post_process(_obj_class_num);

    int ret = release_yolov5_model(&rknn_app_ctx);
    if (ret != 0)
    {
        qDebug("release_yolov5_model fail! ret=%d\n", ret);
    }
    else {
        qDebug("release_yolov5_model success! ret=%d\n", ret);
    }
}

void Rknn::start()
{
    qDebug() << "Rknn start init";
    init();
}


void Rknn::stop()
{
    is_run = false;
    deinit();
}

// 将 object_detect_result 写入文件的函数（如果文件不存在则新建）
void appendToFile(const object_detect_result& result, const std::string& filePath) {
    // 以追加模式打开文件，如果文件不存在则新建
    std::ofstream file(filePath, std::ios::app);

    // 检查文件是否成功打开
    if (!file.is_open()) {
        std::cerr << "Unable to open or create file: " << filePath << std::endl;
        return;
    }

    // 写入数据，格式为：box.left box.top box.right box.bottom prop cls_id
    file << "box: " << result.box.left << " " << result.box.top << " "
         << result.box.right << " " << result.box.bottom << "\n";
    file << "prop: " << result.prop << "\n";
    file << "cls_id: " << result.cls_id << "\n";
    file << "----------------------\n";  // 分隔不同结果

    // 关闭文件
    file.close();
}

void Rknn::start_inference(const QImage &image)
{

    //qDebug() << "start_inference";
    /*QElapsedTimer timer_test;
    timer_test.start();*/

    _img = image;
    is_infernce = true;

    image_buffer_t src_image;
    src_image.width = _img.width();
    src_image.height = _img.height();
    src_image.format = IMAGE_FORMAT_RGB888;
    src_image.virt_addr = _img.bits();
    src_image.size = src_image.width * src_image.height * 3 * sizeof(unsigned char);

    object_detect_result_list od_results;

    int ret = inference_yolov5_model(&rknn_app_ctx, &src_image, &od_results, _obj_class_num, _prob_box_size);
    if (ret != 0)
    {
        qDebug() << "init_yolov5_model fail! ret=" <<  ret;
        return;
    }

    int res = 0;
    // 画框和概率
    char text[256];
    for (int i = 0; i < od_results.count; i++)
    {
        object_detect_result *det_result = &(od_results.results[i]);
        /*printf("%s @ (%d %d %d %d) %.3f\n", coco_cls_to_name(det_result->cls_id),
               det_result->box.left, det_result->box.top,
               det_result->box.right, det_result->box.bottom,
               det_result->prop);*/
        int x1 = det_result->box.left;
        int y1 = det_result->box.top;
        int x2 = det_result->box.right;
        int y2 = det_result->box.bottom;

#if 0
        draw_rectangle(&src_image, x1, y1, x2 - x1, y2 - y1, COLOR_BLUE, 3);
        sprintf(text, "%s %.1f%%", coco_cls_to_name(_obj_class_num, det_result->cls_id), det_result->prop * 100);
        draw_text(&src_image, text, x1, y1 - 20, COLOR_RED, 10);
#endif


        //TODO 判断是否在框中
        if (x1 > _rect_top_left.x()  && x1 < _rect_right_bottom.x() &&
                y1 > _rect_top_left.y() && y1 < _rect_right_bottom.y() &&
                x2 > _rect_top_left.x() && x2 <_rect_right_bottom.x() &&
                y2 > _rect_top_left.y() && y2 < _rect_right_bottom.y()) {
            res = 1;
        }
#if 0
        qDebug() << QThread::currentThreadId() << "screen top_left:" << _rect_top_left;
        qDebug() << QThread::currentThreadId() << "screen right_bottom:"  << _rect_right_bottom;
        qDebug() << QThread::currentThreadId() << "inference top_left:" << QPoint(x1, y1);
        qDebug() << QThread::currentThreadId() << "inference right_bottom:"  << QPoint(x2, y2);
#endif

#if 0
        qDebug() << QThread::currentThreadId() << this->objectName()
                 << "label:" << coco_cls_to_name(_obj_class_num, det_result->cls_id) << QThread::currentThreadId() << ", in rect: " << res;
#endif
    }

#if 0
    if(res == 1){
        if(!this->objectName().compare("Empty_Guangai")){
            write_image((QString("%1/Empty_Guangai/%2.png").arg(storage_img_path).arg(storage_empty_guangai_img_num)).toStdString().c_str(), &src_image);
            storage_empty_guangai_img_num += 1;
        }
        else if(!this->objectName().compare("Common_Guangai")){
            write_image((QString("%1/Common_Guangai/%2.png").arg(storage_img_path).arg(storage_common_guangai_img_num)).toStdString().c_str(), &src_image);
            storage_common_guangai_img_num += 1;
        }
    }
#endif


    /*qDebug() << QThread::currentThreadId() << "infernce_res: " << res;
    qDebug() << QThread::currentThreadId() << "inferenceImage: " << timer_test.elapsed() << " milliseconds.";*/
#if 0
    qDebug() << QThread::currentThreadId() << this->objectName() << " infernce finished, recogizede num: " << od_results.count;
    qDebug() << QThread::currentThreadId() << this->objectName() << "=================================================================";
    #endif
    emit(infernce_res(res));
}

void Rknn::start_human_inference(const QImage &image)
{

    //qDebug() << "start_human_inference";

    /*QElapsedTimer timer_test;
    timer_test.start();*/

    _img = image;
    is_infernce = true;

    image_buffer_t src_image;
    src_image.width = _img.width();
    src_image.height = _img.height();
    src_image.format = IMAGE_FORMAT_RGB888;

    src_image.virt_addr = _img.bits();
    src_image.size = src_image.width * src_image.height * 3 * sizeof(unsigned char);

    object_detect_result_list od_results;

    int ret = inference_yolov5_model(&rknn_app_ctx, &src_image, &od_results, _obj_class_num, _prob_box_size);
    if (ret != 0)
    {
        qDebug() << "init_yolov5_model fail! ret=" <<  ret;
        return;
    }

    int res = 0;
    // 画框和概率
    char text[256];
    for (int i = 0; i < od_results.count; i++)
    {
        object_detect_result *det_result = &(od_results.results[i]);
        /*printf("%s @ (%d %d %d %d) %.3f\n", coco_cls_to_name(det_result->cls_id),
               det_result->box.left, det_result->box.top,
               det_result->box.right, det_result->box.bottom,
               det_result->prop);*/
#if 1
        int x1 = det_result->box.left;
        int y1 = det_result->box.top;
        int x2 = det_result->box.right;
        int y2 = det_result->box.bottom;
#if 1
        draw_rectangle(&src_image, x1, y1, x2 - x1, y2 - y1, COLOR_BLUE, 3);
        sprintf(text, "%s %.1f%%", coco_cls_to_name(_obj_class_num, det_result->cls_id), det_result->prop * 100);
        draw_text(&src_image, text, x1, y1 - 20, COLOR_RED, 10);
#endif
#endif
        // 0是安全帽  1是未带安全帽
        if(det_result->cls_id == 0 && det_result->prop > 0.6){
        //if(det_result->cls_id == 0) {
            res = 1;
            //appendToFile(*det_result, (QString("%1/human/%2.txt").arg(storage_img_path).arg(storage_human_img_num)).toStdString());
        }
#if 0
        qDebug() << QThread::currentThreadId() << "get cls: " << det_result->cls_id
                 << ", label:" << coco_cls_to_name(_obj_class_num, det_result->cls_id)
                 << ", prop:" << det_result->prop * 100;
#endif
    }

#if 1
    if(res == 1){
        write_image((QString("%1/human/%2.png").arg(storage_img_path).arg(storage_human_img_num)).toStdString().c_str(), &src_image);
        storage_human_img_num += 1;
        qDebug() << "save: " << QString("%1/human/%2.png").arg(storage_img_path).arg(storage_human_img_num);
    }
#endif

#if 0

    qDebug() << QThread::currentThreadId() << "inferenceImage: " << timer_test.elapsed() << " milliseconds.";
#endif
#if 0
    if(od_results.count > 0){
        qDebug() << QThread::currentThreadId() << "infernce_res: " << res;
        qDebug() << QThread::currentThreadId() << "infernce finished, recogizede num: " << od_results.count;
        qDebug() << QThread::currentThreadId() << "=================================================================";
    }
#endif
    emit(infernce_res(res));
}

void Rknn::stop_inference()
{
    is_infernce = false;
}

void Rknn::set_recongnize_rect(QPoint top_left, QSize size)
{
    //_rect_top_left = top_left;
    //_rect_size = size;
    qDebug() << "set_recongnize_rect: " << top_left << size;

    _rect_top_left = convertCoordinates(top_left, _screen_size, _img_size);
    _rect_right_bottom = convertCoordinates(QPoint(_rect_top_left.x() + size.width(), _rect_top_left.y() + size.height()), _screen_size, _img_size);

    qDebug() << "from " << _screen_size << top_left << "convertCoordinates " << _img_size << _rect_top_left;
    qDebug() << "from " << _screen_size << QPoint(_rect_top_left.x() + size.width(), _rect_top_left.y() + size.height()) << "convertCoordinates " << _img_size << _rect_right_bottom;

}

QPoint Rknn::convertCoordinates(const QPoint &p, const QSize &fromRes, const QSize &toRes)
{
    // 检查分辨率是否有效
    /*if (fromRes.width() <= 0 || fromRes.height() <= 0 || toRes.width() <= 0 || toRes.height() <= 0) {
        throw std::invalid_argument("Resolution dimensions must be positive and non-zero");
    }*/

    // 转换坐标
    int newX = (p.x() * toRes.width()) / fromRes.width();
    int newY = (p.y() * toRes.height()) / fromRes.height();

    // 保证新坐标在目标分辨率范围内
    newX = std::max(0, std::min(newX, toRes.width() - 1));
    newY = std::max(0, std::min(newY, toRes.height() - 1));

    return QPoint(newX, newY);
}
